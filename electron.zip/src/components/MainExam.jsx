import { useEffect, useState } from "react";

function MainExam({ time }) {
  const [questionId, setQuestionId] = useState(1);

  const [question, setQuestion] = useState(null);

  const [selectedOption, setSelectedOption] = useState(null);

  const totalQuestions = 5;

  async function getQuestion(id) {
    const response = await fetch(`http://localhost:3000/exam/mcq/${id}`);

    const data = await response.json();

    setQuestion(data);
  }

  useEffect(() => {
    async function loadFirstQuestion() {
      await getQuestion(1);
    }

    loadFirstQuestion();
  }, []);

  async function nextQuestion() {
    if (questionId === totalQuestions) {
      return;
    }

    const nextId = questionId + 1;

    setQuestionId(nextId);
    setSelectedOption(null);

    await getQuestion(nextId);
  }

  async function previousQuestion() {
    if (questionId === 1) {
      return;
    }

    const previousId = questionId - 1;

    setQuestionId(previousId);
    setSelectedOption(null);

    await getQuestion(previousId);
  }

  async function endTest() {
    console.log("End Test clicked");
  }

  return (
    <div className="exam-page">
      <div className="exam-container">
        {/* Exam Header */}

        <div className="exam-header">
          <h3>Time Left: {time}</h3>

          <button className="end-test-btn" onClick={endTest}>
            End Test
          </button>
        </div>

        {/* Question */}

        {question && (
          <div className="question-card">
            <h2>
              Question {questionId} of {totalQuestions}
            </h2>

            <p>{question.question}</p>

            {/* Options */}

            {question.options.map((option, index) => (
              <label key={index} className="option-row">
                <input
                  type="radio"
                  name="answer"
                  checked={selectedOption === index}
                  onChange={() => setSelectedOption(index)}
                />

                <span>{option}</span>
              </label>
            ))}

            {/* Navigation */}

            <div className="navigation-buttons">
              <button onClick={previousQuestion} disabled={questionId === 1}>
                Previous
              </button>

              <button
                onClick={nextQuestion}
                disabled={questionId === totalQuestions}
              >
                Next
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default MainExam;
