import { useEffect, useRef, useState } from "react";
import "./App.css";
import MainExam from "./components/MainExam";

function App() {
  const videoRef = useRef(null);
  const canvaRef = useRef(null);

  const [time, setTime] = useState(0);
  const [started, setStarted] = useState(false);
  const [cameraReady, setCameraReady] = useState(false);

  async function getLaspedTime() {
    const currTime = await window.electronAPI.getRemainingTime();

    setTime(currTime);
  }

  useEffect(() => {
    if (!started) return;

    const interval = setInterval(() => {
      getLaspedTime();
    }, 1000);

    return () => clearInterval(interval);
  }, [started]);

  async function getCamera() {
    const videoData = await navigator.mediaDevices.getUserMedia({
      video: true,
    });

    videoRef.current.srcObject = videoData;

    setCameraReady(true);
  }

  async function getFullscreen() {
    await window.electronAPI.setFullScreen();
  }

  async function startTest() {
    const res = await window.electronAPI.showRules();

    if (res === 0) {
      await window.electronAPI.startTest();

      setStarted(true);
    }
  }

  async function takePhoto() {
    const video = videoRef.current;
    const canva = canvaRef.current;

    if (!video || !canva) return;

    if (video.videoWidth === 0) return;

    canva.width = video.videoWidth;
    canva.height = video.videoHeight;

    const ctx = canva.getContext("2d");

    ctx.drawImage(video, 0, 0);

    const image = canva.toDataURL("image/png");

    await window.electronAPI.savePhoto(image);
  }

  useEffect(() => {
    if (!started) return;

    const interval = setInterval(() => {
      takePhoto();
    }, 1000);

    return () => clearInterval(interval);
  }, [started]);

  function formatTimeLeft(ms) {
    const seconds = Math.floor((ms / 1000) % 60)
      .toString()
      .padStart(2, "0");

    const minutes = Math.floor((ms / (1000 * 60)) % 60)
      .toString()
      .padStart(2, "0");

    const hours = Math.floor(ms / (1000 * 60 * 60))
      .toString()
      .padStart(2, "0");

    return `${hours}:${minutes}:${seconds}`;
  }

  return (
    <>
      {/* 
        Video always stays mounted.
        When exam starts we only hide it.
      */}
      <video
        ref={videoRef}
        autoPlay
        muted
        className={cameraReady && !started ? "video-preview" : "hidden-video"}
      />

      <canvas ref={canvaRef} style={{ display: "none" }} />

      {started ? (
        <MainExam time={formatTimeLeft(time)} />
      ) : (
        <div className="page-container">
          <div className="header-section">
            <h1>Hi Aditya!</h1>

            <p>Kindly Allow the following Permissions to Start the test:</p>
          </div>

          <div className="card-container">
            {/* Camera */}

            <div className="permission-item">
              <div className="permission-icon">↗</div>

              <div className="permission-content">
                <h3>Configure Camera</h3>

                <p>Kindly configure Camera to attempt quiz/contests.</p>

                <div className="action-row">
                  <button onClick={getCamera} className="btn btn-dark">
                    Get Camera Access
                  </button>
                </div>

                {cameraReady && <div className="camera-space" />}
              </div>
            </div>

            <div className="divider" />

            {/* Fullscreen */}

            <div className="permission-item">
              <div className="permission-icon">⛶</div>

              <div className="permission-content">
                <h3>Switch to full screen</h3>

                <p>Kindly close all tabs and switch to full screen.</p>

                <button onClick={getFullscreen} className="btn btn-light-blue">
                  Give Full Screen Permissions
                </button>
              </div>
            </div>
          </div>

          <div className="bottom-actions">
            <button onClick={startTest} className="btn btn-light-blue">
              Go To Test
            </button>

            <button className="btn btn-outline">Need Help?</button>
          </div>
        </div>
      )}
    </>
  );
}

export default App;
