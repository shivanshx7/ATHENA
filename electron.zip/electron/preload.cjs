const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("electronAPI", {
  setFullScreen: () => ipcRenderer.invoke("full-screen"),
  getRemainingTime: () => ipcRenderer.invoke("get-time"),
  startTest: () => ipcRenderer.invoke("start-test"),
  showRules: () => ipcRenderer.invoke("show-rules"),
  savePhoto: (image) => ipcRenderer.invoke('save-photo', image)
});


// 5:00 pm - start time // server


// Time now : 6:07 - Current time

// Time remaining = 2hrs - (current - start_time)