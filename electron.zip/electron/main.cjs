const {
  BrowserWindow,
  app,
  ipcMain,
  dialog,
  nativeTheme,
} = require("electron");
const path = require("path");
const fs = require("fs");

let win = null;

function createWindow() {
  win = new BrowserWindow({
    width: 1000,
    height: 700,
    frame: false,
    webPreferences: {
      preload: path.join(__dirname, "preload.cjs"),
    },
  });

  win.loadURL("http://localhost:5173/");
  win.webContents.openDevTools({ mode: "detach" });
}

ipcMain.handle("full-screen", () => {
  win.kiosk = true;
});

let end_time = null;

ipcMain.handle("start-test", () => {
  end_time = Date.now() + 60 * 60 * 60;
});

ipcMain.handle("get-time", () => {
  return end_time - Date.now();
});

ipcMain.handle("show-rules", async () => {
  const result = await dialog.showMessageBox(win, {
    type: "info",
    title: "Exam Rules",
    message: "Please read the exam rules carefully.",
    detail: `
1. Camera must remain enabled.
2. Do not exit fullscreen mode.
3. Do not use external applications.
4. The exam will start only after accepting the rules.
    `,
    buttons: ["Accept", "Cancel"],
    defaultId: 0,
    cancelId: 1,
  });

  return result.response;
});

ipcMain.handle("save-photo", (event, image) => {
  const imageData = image.split(",")[1];

  const filePath = path.join(
    __dirname,
    "camera_feed",
    `photo-${Date.now()}.png`,
  );
  fs.writeFileSync(filePath, Buffer.from(imageData, "base64"));

  return filePath;
});

app.whenReady().then(() => {
  nativeTheme.themeSource = "system";
  createWindow();
});
