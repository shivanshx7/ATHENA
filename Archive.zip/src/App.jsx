import { useRef } from "react";
import "./App.css";

function App() {
  const videoRef = useRef(null);

  async function getCamera() {
    const videoData = await navigator.mediaDevices.getUserMedia({
      video: true,
    });
    videoRef.current.srcObject = videoData;
  }

  async function getFullscreen(){
    await document.documentElement.requestFullscreen()
  }

  return (
    <div className="page-container">
      <div className="card-container">
        {/* Section 1: Camera */}
        <div className="permission-item">
          <div className="permission-content">
            <h3>Configure Camera</h3>
            <p>Kindly configure Camera to attempt quiz/contests.</p>
            <div className="action-row">
              <button onClick={getCamera} className="btn btn-black">
                Get Camera Access
              </button>

              {/* Video Feed Preview */}
              <video autoPlay ref={videoRef} className={`video-preview`} />
            </div>
          </div>
        </div>

        <div className="divider"></div>

        {/* Section 2: Fullscreen */}
        <div className="permission-item">
          <div className="permission-content">
            <h3>Switch to full screen</h3>
            <button onClick={getFullscreen} className="btn btn-primary">
              Give Full Screen Permissions
            </button>
          </div>
        </div>
      </div>

      {/* Bottom Action Buttons */}
      <div className="bottom-actions">
        <button className="btn btn-primary">Go To Test</button>
      </div>
      <div>{`Time Left: Minutes Seconds`}</div>
    </div>
  );
}

export default App;
